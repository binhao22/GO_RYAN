import pygame
import random
import sys
from time import sleep

BLACK = (0, 0, 0)
GRAY = (166, 166, 166)
WHITE = (255, 255, 255)
WINDOW_WIDTH = 600
WINDOW_HEIGHT = 849

class Character :
    img_player = ['_player.png','_player2.png']
    img_obstacle = []
    
    for i in range(1,21) :
        if i < 10 :
            img_obstacle.append("C" + str(i) + ".png")
        else :
            img_obstacle.append("C" + str(i) + ".png")

    def load_player(self) :
        self.image = pygame.image.load(random.choice(self.img_player))
        self.width = self.image.get_rect().size[0]
        self.height = self.image.get_rect().size[1]

    def load_obstacle(self) :
        self.image = pygame.image.load(random.choice(self.img_obstacle))
        self.width = self.image.get_rect().size[0]
        self.height = self.image.get_rect().size[1]

    def draw_image(self) :
        screen.blit(self.image, [self.x, self.y])

    def __init__(self, x=0, y=0, dx=0, dy=0) :
        self.image = ""
        self.x = x
        self.y = y
        self.dx = dx
        self.dy = dy

    def move_x(self) :
        self.x += self.dx
    
    def move_y(self) :
        self.y += self.dy

    def out_map(self) :
        if self.x + self.width > WINDOW_WIDTH or self.x < 0 :
            self.x -= self.dx

    def end_game(self, obstacles) :
        if (self.x + self.width > obstacles.x) and (self.x < obstacles.x + obstacles.width) and (self.y < obstacles.y + obstacles.height) and (self.y + self.height > obstacles.y) :
            return True
        else :
            return False
        
def main_() :
    img_main = pygame.image.load('_BACKGROUND.png')
    font_25 = pygame.font.SysFont("Century", 25, True, False)
    font_60 = pygame.font.SysFont("Century", 60, True, False)
    draw_x = 0
    draw_y = 0
    screen.blit(img_main, [draw_x, draw_y])
    text_score = font_25.render("SCORE : " + str(score), True, WHITE)
    screen.blit(text_score, [WINDOW_WIDTH / 2 - 70, WINDOW_HEIGHT / 2 + 250])
    text_start = font_60.render("START", True, WHITE)
    screen.blit(text_start, [WINDOW_WIDTH / 2 - 115, WINDOW_HEIGHT / 2 + 300])
    pygame.display.flip()

def score_() :
    font_30 = pygame.font.SysFont("Century", 30, True, False)
    text_score = font_30.render("SCORE : " + str(score), True, WHITE)
    screen.blit(text_score, [20, 20])
    
if __name__ == '__main__' :

    pygame.init()
    pygame.mixer.music.load('_BGM.wav')
    sound_END = pygame.mixer.Sound('_END.wav')
    sound_START = pygame.mixer.Sound('_START.wav')
    screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    pygame.display.set_caption("GO, RYAN !!")
    clock = pygame.time.Clock()

    player = Character(WINDOW_WIDTH / 2, WINDOW_HEIGHT -150, 0, 0)
    player.load_player()
    obstacles = []
    obstacle_quantity = 4
    for i in range(obstacle_quantity) :
        x = random.randrange(0, WINDOW_WIDTH - 60)
        y = random.randrange(-180, -70)
        obstacle = Character(x, y, 0, random.randint(4, 8))
        obstacle.load_obstacle()
        obstacles.append(obstacle)
    lanes = []
    lane_quantity = 5
    lane_width = 10
    lane_height = 90
    lane_margin = 30
    lane_x = (WINDOW_WIDTH - lane_width) / 2
    lane_y = 0
    for i in range(lane_quantity) :
        lanes.append([lane_x, lane_y])
        lane_y += lane_height + lane_margin

    score = 0
    END = True
    START = True
    while START :
        for event in pygame.event.get() :
            if event.type == pygame.QUIT :
                START = False

            if END :
                if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE :
                    END = False
                    for i in range(obstacle_quantity) :
                        obstacles[i].x = random.randrange(0, WINDOW_WIDTH - obstacles[i].width)
                        obstacles[i].y = random.randrange(-120, -40)
                        obstacles[i].load_obstacle()

                    player.load_player()
                    player.x = WINDOW_WIDTH / 2
                    player.dx = 0
                    score = 0
                    pygame.mouse.set_visible(False)
                    sound_START.play()
                    sleep(3.5)
                    pygame.mixer.music.play(-1)
                        
            if not END :
                if event.type == pygame.KEYDOWN :
                    if event.key == pygame.K_RIGHT :
                        player.dx = 7
                    elif event.key == pygame.K_LEFT :
                        player.dx = -7

                if event.type == pygame.KEYUP :
                    if event.key == pygame.K_RIGHT :
                        player.dx = 0
                    elif event.key == pygame.K_LEFT :
                        player.dx = 0

        screen.fill(GRAY)

        if not END :
            for i in range(lane_quantity) :
                pygame.draw.rect(screen, WHITE, [lanes[i][0], lanes[i][1], lane_width, lane_height])
                lanes[i][1] += 15
                if lanes[i][1] > WINDOW_HEIGHT :
                    lanes[i][1] = -40 -lane_height

            player.draw_image()
            player.move_x()
            player.out_map()
            
            for i in range(obstacle_quantity) :
                obstacles[i].draw_image()
                obstacles[i].y += obstacles[i].dy
                if obstacles[i].y > WINDOW_HEIGHT :
                    score += 50
                    obstacles[i].x = random.randrange(0, WINDOW_WIDTH - obstacles[i].width)
                    obstacles[i].y = random.randrange(-100, -50)
                    obstacles[i].dy = random.randint(4, 8)
                    obstacles[i].load_obstacle()

            for i in range(obstacle_quantity) :
                if player.end_game(obstacles[i]) :
                    END = True
                    pygame.mixer.music.stop()
                    sound_END.play()
                    sleep(2)
                    pygame.mouse.set_visible(True)
                    break

            score_()
            pygame.display.flip()

        else :
            main_()

        clock.tick(60)

    pygame.quit()



                        

    

